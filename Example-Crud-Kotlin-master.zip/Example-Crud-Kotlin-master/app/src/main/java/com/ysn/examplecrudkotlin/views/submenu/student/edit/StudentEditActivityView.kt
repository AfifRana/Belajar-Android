package com.ysn.examplecrudkotlin.views.submenu.student.edit

import com.ysn.examplecrudkotlin.views.base.View

/**
 * Created by root on 24/06/17.
 */
interface StudentEditActivityView : View {

    fun updateData()

    fun updateDataFailed()

}